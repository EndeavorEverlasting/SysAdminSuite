﻿@echo off
pwsh -NoProfile -ExecutionPolicy Bypass -File "%~dp0New-SourcesTemplate.ps1"
